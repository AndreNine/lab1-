export const banco = [{ code: "MEX", name: "Ciudad de México" },
{ code: "MTY", name: "Monterrey" },
{ code: "GDL", name: "Guadalajara" },
];
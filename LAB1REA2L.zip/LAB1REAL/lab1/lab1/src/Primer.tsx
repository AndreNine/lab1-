import { bancos } from './assets/bancos';

function ComponenteHolaMundo() {
  return <h1>Hola Mundo</h1>;
}

function ComponenteVariables() {
  const nombre = 'Andre';
  const edad = 21;
  const esEstudiante = true;

  return (
    <div>
      <h2>Nombre: {nombre}</h2>
      <h2>Edad: {edad}</h2>
      <h2>Estudiante: {esEstudiante ? 'Sí' : 'No'}</h2>
    </div>
  );
}

function ComponenteBancos() {
  const banco = bancos.find((b) => b.name === 'BBVA');

  return (
    <div>
      <h2>Banco encontrado:</h2>
      <p>{banco ? banco.name : 'No encontrado'}</p>
    </div>
  );
}

function Tarea() {
  return (
    <>
      <ComponenteHolaMundo />
      <ComponenteVariables />
      <ComponenteBancos />
    </>
  );
}

export default Tarea;
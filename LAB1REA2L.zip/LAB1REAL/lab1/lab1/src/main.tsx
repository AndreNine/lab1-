import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import Primer from './Primer.tsx'


createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Primer></Primer>
  </StrictMode>,
)
